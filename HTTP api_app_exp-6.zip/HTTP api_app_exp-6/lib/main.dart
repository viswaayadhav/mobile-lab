import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(ApiExplorerApp());
}

class ApiExplorerApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'API Explorer',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: ApiExplorerHome(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class ApiExplorerHome extends StatefulWidget {
  @override
  _ApiExplorerHomeState createState() => _ApiExplorerHomeState();
}

class _ApiExplorerHomeState extends State<ApiExplorerHome> {
  final TextEditingController _controller = TextEditingController();
  String _response = '';
  bool _isLoading = false;

  Future<void> fetchData() async {
    final url = _controller.text;
    if (url.isEmpty) {
      setState(() => _response = "Please enter a valid API URL.");
      return;
    }

    setState(() {
      _isLoading = true;
      _response = '';
    });

    try {
      final res = await http.get(Uri.parse(url));

      setState(() {
        if (res.statusCode == 200) {
          final data = json.decode(res.body);
          _response = const JsonEncoder.withIndent('  ').convert(data);
        } else {
          _response = 'Error: ${res.statusCode} ${res.reasonPhrase}';
        }
      });
    } catch (e) {
      setState(() {
        _response = 'Error: $e';
      });
    } finally {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('API Explorer')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _controller,
              decoration: InputDecoration(
                labelText: 'Enter API URL',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.url,
            ),
            SizedBox(height: 12),
            ElevatedButton(
              onPressed: fetchData,
              child: Text('Fetch Data'),
            ),
            SizedBox(height: 20),
            _isLoading
                ? CircularProgressIndicator()
                : Expanded(
                    child: SingleChildScrollView(
                      child: SelectableText(
                        _response,
                        style: TextStyle(fontSize: 14, fontFamily: 'Courier'),
                      ),
                    ),
                  ),
          ],
        ),
      ),
    );
  }
}

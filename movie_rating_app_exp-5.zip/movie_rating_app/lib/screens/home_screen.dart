import 'package:flutter/material.dart';
import '../models/movie.dart';
import '../widgets/movie_card.dart';

class HomeScreen extends StatelessWidget {
  final List<Movie> movies = [
    Movie(
      title: "Inception",
      imageUrl:
          "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTIXEj8uzIzxPwCPxb5Hk8oVht7hFsYmJXykw&s",
      rating: 8.8,
      description: "A mind-bending thriller by Christopher Nolan.",
    ),
    Movie(
      title: "The Dark Knight",
      imageUrl:
          "https://i0.wp.com/www.tomrichmond.com/wp-content/uploads/2008/07/29look4.jpg?resize=425%2C287&ssl=1",
      rating: 9.0,
      description: "Batman faces the Joker in this epic movie.",
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Movie Ratings")),
      body: GridView.builder(
        padding: const EdgeInsets.all(10),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2, // Two columns
          childAspectRatio: 0.7,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
        ),
        itemCount: movies.length,
        itemBuilder: (context, index) {
          return MovieCard(movie: movies[index]);
        },
      ),
    );
  }
}

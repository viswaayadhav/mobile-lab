import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:async';
import 'dart:convert';

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  String currentMessage = '';
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    startPolling();
  }

  void startPolling() {
    _timer = Timer.periodic(Duration(seconds: 5), (timer) {
      checkForMessage();
    });
  }

  void checkForMessage() async {
    final url = Uri.parse("http://10.0.2.2:3000/poll"); // For Android emulator
    final response = await http.get(url);
    final data = jsonDecode(response.body);

    if (data['message'] != '' && data['message'] != currentMessage) {
      setState(() {
        currentMessage = data['message'];
      });
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title: Text("New Message"),
          content: Text(currentMessage),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text("OK"),
            ),
          ],
        ),
      );
    }
  }

  void sendMessage() async {
    final url = Uri.parse("http://10.0.2.2:3000/send");
    await http.post(
      url,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'message': 'Hello from Backend'}),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(title: Text("Simulated Push")),
        body: Center(
          child: ElevatedButton(
            onPressed: sendMessage,
            child: Text("Send Message to App"),
          ),
        ),
      ),
    );
  }
}

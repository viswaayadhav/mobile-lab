package com.example.widgets1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

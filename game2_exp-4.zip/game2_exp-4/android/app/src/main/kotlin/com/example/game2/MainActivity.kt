package com.example.game2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

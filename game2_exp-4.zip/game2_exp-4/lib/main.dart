import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(const BallGame());
}

class BallGame extends StatelessWidget {
  const BallGame({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: GameScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class GameScreen extends StatefulWidget {
  const GameScreen({super.key});

  @override
  _GameScreenState createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  double ballX = 0;
  double ballY = 0;
  final double moveAmount = 10;

  void _moveBall(RawKeyEvent event) {
    setState(() {
      if (event is RawKeyDownEvent) {
        if (event.logicalKey == LogicalKeyboardKey.arrowUp) {
          ballY -= moveAmount;
        } else if (event.logicalKey == LogicalKeyboardKey.arrowDown) {
          ballY += moveAmount;
        } else if (event.logicalKey == LogicalKeyboardKey.arrowLeft) {
          ballX -= moveAmount;
        } else if (event.logicalKey == LogicalKeyboardKey.arrowRight) {
          ballX += moveAmount;
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return RawKeyboardListener(
      focusNode: FocusNode(),
      autofocus: true,
      onKey: _moveBall,
      child: Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: Stack(
            children: [
              Positioned(
                left: ballX + MediaQuery.of(context).size.width / 2,
                top: ballY + MediaQuery.of(context).size.height / 2,
                child: Container(
                  width: 30,
                  height: 30,
                  decoration: const BoxDecoration(
                    color: Colors.blue,
                    shape: BoxShape.circle,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

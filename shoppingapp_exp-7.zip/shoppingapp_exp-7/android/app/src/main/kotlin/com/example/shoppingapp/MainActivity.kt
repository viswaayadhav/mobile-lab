package com.example.shoppingapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
